package com.example.activityresult;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        EditText inputText = findViewById(R.id.input_text);
        Button completeButton = findViewById(R.id.complete_button);
        Button cancelButton = findViewById(R.id.cancel_button);

        completeButton.setOnClickListener(v -> {
            String enteredText = inputText.getText().toString();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("returned_text", enteredText);
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        cancelButton.setOnClickListener(v -> finish());
    }
}