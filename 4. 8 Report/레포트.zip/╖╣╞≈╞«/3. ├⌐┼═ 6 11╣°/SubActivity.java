package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");
        String password = intent.getStringExtra("PASSWORD");

        TextView usernameTextView = findViewById(R.id.username_textview);
        TextView passwordTextView = findViewById(R.id.password_textview);

        usernameTextView.setText("Username: " + username);
        passwordTextView.setText("Password: " + password);
    }
}