package com.example.check;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroupVersions;
    RadioButton radioButton233, radioButton41, radioButton44;
    Button buttonDisplayImage;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Activity title 설정
        setTitle("Survey");

        radioGroupVersions = findViewById(R.id.radioGroupVersions);
        radioButton233 = findViewById(R.id.radioButton233);
        radioButton41 = findViewById(R.id.radioButton41);
        radioButton44 = findViewById(R.id.radioButton44);
        buttonDisplayImage = findViewById(R.id.buttonDisplayImage);
        imageView = findViewById(R.id.imageView);

        // DISPLAY IMAGE 버튼 클릭 시 이미지 출력/숨기기 기능
        buttonDisplayImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageView.getVisibility() == View.VISIBLE) {
                    imageView.setVisibility(View.INVISIBLE);
                } else {
                    imageView.setVisibility(View.VISIBLE);
                }
            }
        });

        // 라디오 버튼 선택 시 이미지 변경
        radioGroupVersions.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton233) {
                    imageView.setImageResource(R.drawable.image0);
                } else if (checkedId == R.id.radioButton41) {
                    imageView.setImageResource(R.drawable.image1);
                } else if (checkedId == R.id.radioButton44) {
                    imageView.setImageResource(R.drawable.image2);
                }
            }
        });
    }
}