package com.example.check4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    CheckBox checkBoxPHP, checkBoxJava, checkBoxC, checkBoxCpp, checkBoxPython;
    Button buttonDone, buttonCancel;
    TextView textViewSelection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkBoxPHP = findViewById(R.id.checkBoxPHP);
        checkBoxJava = findViewById(R.id.checkBoxJava);
        checkBoxC = findViewById(R.id.checkBoxC);
        checkBoxCpp = findViewById(R.id.checkBoxCpp);
        checkBoxPython = findViewById(R.id.checkBoxPython);
        buttonDone = findViewById(R.id.buttonDone);
        buttonCancel = findViewById(R.id.buttonCancel);
        textViewSelection = findViewById(R.id.textViewSelection);

        buttonDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder selectedLanguages = new StringBuilder();
                if (checkBoxPHP.isChecked()) {
                    selectedLanguages.append("PHP, ");
                }
                if (checkBoxJava.isChecked()) {
                    selectedLanguages.append("JAVA, ");
                }
                if (checkBoxC.isChecked()) {
                    selectedLanguages.append("C, ");
                }
                if (checkBoxCpp.isChecked()) {
                    selectedLanguages.append("C++, ");
                }
                if (checkBoxPython.isChecked()) {
                    selectedLanguages.append("PYTHON");
                }
                String selection = selectedLanguages.toString().replaceAll(", $", "");
                textViewSelection.setText(selection);
            }
        });
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkBoxPHP.setChecked(false);
                checkBoxJava.setChecked(false);
                checkBoxC.setChecked(false);
                checkBoxCpp.setChecked(false);
                checkBoxPython.setChecked(false);
                textViewSelection.setText("");
            }
        });
    }
}