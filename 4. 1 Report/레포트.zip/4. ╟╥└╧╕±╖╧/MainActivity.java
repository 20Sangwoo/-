package com.example.check2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    EditText editTextTask;
    Button buttonAdd;
    LinearLayout linearLayoutTasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTask = findViewById(R.id.editTextTask);
        buttonAdd = findViewById(R.id.buttonAdd);
        linearLayoutTasks = findViewById(R.id.linear_layout_tasks);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });
    }
    private void addTask() {
        String taskText = editTextTask.getText().toString().trim();
        if (!taskText.isEmpty()) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(taskText);
            linearLayoutTasks.addView(checkBox);
            editTextTask.setText("");
            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox clickedCheckBox = (CheckBox) v;
                    if (clickedCheckBox.isChecked()) {
                        clickedCheckBox.setTextColor(getResources().getColor(android.R.color.darker_gray));
                    } else {
                        clickedCheckBox.setTextColor(getResources().getColor(android.R.color.black));
                    }
                }
            });         }}}